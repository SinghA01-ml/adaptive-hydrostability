%RAYTEST generate label data 

global BATCH bsn FID
setpath
BATCH=1;

tstart = tic; %------- start timing
fprintf('Generating Rayleigh-Benard convection test data set ... ')

%----- setup problem data files
system('/bin/cp ./boussinesq_flow/test_problems/bottom_bcX.m ./diffusion/specific_bc.m');
system('/bin/cp ./stokes_flow/test_problems/no_flow.m ./stokes_flow/specific_flow.m');
system('/bin/cp ./diffusion/test_problems/zero_bc.m ./stokes_flow/stream_bc.m');

% ---- preprocessing to set up grid and coefficient matrices
testproblem=['B-NS42_grid_batch'];

%---------- write the batch file
      [KID,message]=fopen(testproblem,'w');
      fprintf(KID,'2%%\n1%%\n1%%\n32%%\n2%%\n1%%\n1%%\n');
      fprintf(KID,'%59s\n','%---------- grid data file for Rayleigh-Benard test problem');
      fclose(KID);

%---------- set up matrices
      [FID,message]=fopen(testproblem,'r');
      if strcmp(message,'')~=1, error(['INPUT FILE ERROR: ' message])
      else, disp(['Working in batch mode from data file ',testproblem])
      end
      bsn=1; cavity_boussX

%------- run through test data points in parallel
Re = [1300, 1600]; %<--- Rayleigh numbers
delta = [1e-16, 1e-8, 1e-6, 1e-4, 1e-2]; %<--- perturbations to inflow

[RE, DELTA] = ndgrid(Re, delta);
ras      = RE(:);
deltaset = DELTA(:);
nCases = numel(ras);

%---------- parallel matlab stuff
parpool(nCases)
pp=gcp;
parfor test=1:nCases
      tt=test;
      fprintf(['\n [%g]'],tt)
      ra=ras(tt); RA=ra;
      fprintf(['\n Rayleigh number %g'],ra)
      delta=deltaset(tt); DELTA = delta;
      fprintf(['\n perturbation magnitude is %g\n'],DELTA)
      testproblem=['B-NS42_test',num2str(tt)];
      batchfile=[testproblem,'_batch.m'];

%---------- write the batch file
      [FID,message]=fopen(batchfile,'w');
      fprintf(FID,'%g%%\n7.1%%\n%g%%\n',ra,delta);
      fprintf(FID,'1e16%%\n3%%\n1e-6%%\n0%%\n30%%\n0%%\n0%%\n13%%\n');
      fprintf(FID,'%53s\n','%---------- data file for Rayleigh-Benard test problem');
      fclose(FID);

%---------- execute the batch file and compute the label
      batchprocess(testproblem)
end
delete(gcp)
etoc = toc(tstart);
fprintf('Bingo!\n')
fprintf('\n  %9.4e seconds\n\n\n',etoc)

%---------- open results file
gohome, cd datafiles
[RID,message]=fopen('problem2.txt','w');
fprintf(RID,'%33s\n','%------------ grid32 label results');
for test=1:nCases
   testresults=['Bouss_output',num2str(test),'.mat'];
   load(testresults)
   figure(25+test),subplot(121)
   plot(1:length(KE),KE,'ob:'), axis square
   title('kinetic energy')
   subplot(122)
   plot(1:length(VTY),VTY,'ok:'), axis square
   title('mean vorticity')
%---------- check for equilibrium solution
   ke=KE(end); omega=VTY(end);
   if KE(end)<3e-3, label=0; else, label=1; end
%---------- check for incomplete time integration
   if 801==length(time), flag=0; else, flag=1; end
%---------- write the result to the file
   fprintf(RID,'%g,%g,%g,%g,%g,%g\n',Ra,delta,label,ke,omega,flag);
   fprintf('Label results saved for test %g\n',test)
end
fclose(RID);
fprintf('All done\n')


