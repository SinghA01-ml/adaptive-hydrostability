import numpy as np
import os
import tensorflow as tf
from tensorflow.keras.optimizers.legacy import SGD
from tensorflow.keras.optimizers import Adam
import matplotlib.pyplot as plt

import BR_lib.BR_model as BR_model
import BR_lib.BR_data as BR_data
import shallowNN_tf as nn_clf
import subprocess


# Returns the parameter bounds (lower and upper) in physical space for the chosen problem setup.
def get_problem_bounds(probsetup):
    """
    Return parameter bounds for each hydrodynamic problem setup.
    Each problem defines ranges for two parameters.
    """
    if probsetup == 1:
        # Problem 1: Symmetry-breaking channel flow
        # Parameters: Reynolds number, perturbation magnitude 
        bounds = {
            "Re": (160.0, 230.0),          # Reynolds number
            "logdelta": (-5.0, -2.0)       # log10(delta)
        }

    elif probsetup == 2:
        # Problem 2: Rayleigh--Benard convection
        # Parameters: Rayleigh number, asymmetry magnitude of base temperature
        bounds = {
            "Ra": (1300, 1600),         # Rayleigh number 
            "asymT": (-16, -2)          # log10(delta)
        }

    elif probsetup == 3:
        # Problem 3: Differentially heated cavity
        # Parameters: Rayleigh number, Prandtl number
        bounds = {
            "Ra": (2.7e9, 3.2e9),          # Rayleigh number
            "Pr": (0.71, 1000)             # Prandtl number
        }

    else:
        raise ValueError(f"Unknown probsetup {probsetup}")

    return bounds

# Maps physical parameters into normalized z-space within [-1, 1]^2 using given bounds.
def to_z(params, bounds):
    """
    Map physical parameters -> z-space in [-1,1]^2.
    params: ndarray (N,2)
    bounds: dict from get_problem_bounds
    """
    keys = list(bounds.keys())
    z = []

    for j, key in enumerate(keys):
        lo, hi = bounds[key]

        if key.lower() in ["logdelta"]:  
            # already log10 in file
            vals = params[:, j]
            z_j = 2 * (vals - lo) / (hi - lo) - 1
        else:
            vals = params[:, j]
            z_j = 2 * (vals - lo) / (hi - lo) - 1

        z.append(z_j)

    return np.stack(z, axis=1).astype(np.float32)

# Maps normalized z-space coordinates back to physical parameter space using given bounds.
def to_physical(z, bounds):
    """
    Map z-space [-1,1]^2 -> physical parameters.
    z: ndarray (N,2)
    bounds: dict from get_problem_bounds
    """
    keys = list(bounds.keys())
    params = []

    for j, key in enumerate(keys):
        lo, hi = bounds[key]
        vals = lo + (z[:, j] + 1) * 0.5 * (hi - lo)
        params.append(vals)

    return np.stack(params, axis=1).astype(np.float32)



def load_stage1_data(probsetup, bounds, data_dir="./data"):
    """
    Load Stage-1 training data for the classifier neural network.
    
    Args:
        probsetup : int
            Problem setup index (1,2,3).
        bounds : dict
            Parameter(input) bounds from get_problem_bounds(probsetup).
        data_dir : str
            Path to the folder containing problem1.txt, problem2.txt, problem3.txt.
    
    Returns:
        z_train : (N,2) array in [-1,1]^2
        y_train : (N,) array of integer labels
        params  : (N,2) array of physical parameters 
    """

    # pick the file
    fname = os.path.join(data_dir, f"problem{probsetup}.txt")
    if not os.path.exists(fname):
        raise FileNotFoundError(f"Stage-1 data file not found: {fname}")

    raw = np.loadtxt(fname, comments='%', delimiter=',').astype(np.float32)

    if probsetup == 1:
        # File columns: Re, delta, label, it, ib, flag
        Re = raw[:,0]
        delta = raw[:,1]
        labels = raw[:,2].astype(int)

        # Compute log10(delta)
        logdelta = np.log10(delta)
        params = np.stack([Re, logdelta], axis=1)


    elif probsetup == 2:
        # File columns: Ra, perturbation, label, KE, vty, flag
        Ra   = raw[:, 0]
        pert = raw[:, 1]
        lab0 = raw[:, 2].astype(int)
        KE   = raw[:, 3]

        # Refine label by KE threshold
        KE_THRESH = 5e-4
        labels = np.where(KE > KE_THRESH, 1, lab0).astype(int)

        # Compute log10(delta)
        logpert = np.log10(pert + 1e-300)
        params  = np.stack([Ra, logpert], axis=1)

    elif probsetup == 3:
        # File columns: Ra, Pr, label, it, ib, flag
        Ra = raw[:,0]
        Pr = raw[:,1]
        labels = raw[:,2].astype(int)

        params = np.stack([Ra, Pr], axis=1)

    else:
        raise ValueError(f"Unknown probsetup {probsetup}")

    # scale to z-space
    z_train = to_z(params, bounds)

    return z_train, labels, params


# Encode integer labels into one-hot format:
def member_encode(y: int):
    return [1, 0] if int(y) == 1 else [0, 1]


# =====================================================================================
# BifurcationDAS: adaptive classification method
# =====================================================================================
class BifurcationDAS:
    """
        Adaptive sampling for hydrodynamic stability.
        - Inputs live in z-space ([-1,1]^2) via fixed affine mapping.
        - Stage 1 uses precomputed labeled file.
        - Later stages will use KRNet to propose points, then MATLAB to label them.
    """
    def __init__(self, args, eng=None):
        self.args = args
        self.bounds = get_problem_bounds(args.probsetup)

        # Initializes optimizers, directories, and tracking variables.
        self._set()
        # Builds the classifier neural network.
        self.build_classifier()
        # Builds the KRnet flow model for adaptive sampling.
        self.build_flow()      
        # Restores checkpoints and checkpoint manager for training continuation.
        self._restore()

    # -------------------- setup / restore --------------------
    def _set(self):
        """Set optimizers, create folders."""
        args = self.args

         # --- Optimizer for classifier neural network---
        if args.optim == 'sgd':
            self.clf_optimizer = SGD(learning_rate=0.15)
        elif args.optim == 'adam':
            self.clf_optimizer = Adam(learning_rate=args.lr)

        # --- Optimizer for KRNet ---
        self.flow_optimizer = Adam(learning_rate=self.args.lr, clipnorm=1.0)


        # Create directories for checkpoints, summaries, and data
        os.makedirs(args.ckpts_dir, exist_ok=True)
        os.makedirs(args.summary_dir, exist_ok=True)
        os.makedirs(args.data_dir, exist_ok=True)


    
        self.cls_loss_vs_iter_all= []# classifier neural network loss values across iterations
        self.cls_loss_vs_epoch_all = []# classifier neural network loss values across epochs

        # Classifier neural network accuracy across iterations
        self.cls_acc_vs_iter_all  = []

        self.entropyloss_vs_iter_all = []# KRNet entropy-based loss values across iterations
        self.entropyloss_vs_epoch_all = []#KRNet entropy-based loss values across epochs

        self.loss_fn = tf.keras.losses.CategoricalCrossentropy()


    def _restore(self):
        """Setup checkpoint manager for saving/loading classifier models."""
        args = self.args

        self.ckpt = tf.train.Checkpoint(step=tf.Variable(0),
                                        optimizer=self.clf_optimizer,
                                        net=self.classifier)
        self.manager = tf.train.CheckpointManager(self.ckpt,
                                                  self.args.ckpts_dir,
                                                  max_to_keep=5)

    # -------------------- models --------------------
    def build_classifier(self):
        """Define classifier neural network."""
        a = self.args
        self.classifier = nn_clf.ClassificationNN(
            input_dim=2,
            num_hidden_layers=a.nn_depth,
            hidden_neurons=a.n_hidden_nn,
            activation_hidden=a.activation_nn
        )
        _ = self.classifier(tf.zeros((1,2), dtype=tf.float32))  # build graph

    def build_flow(self):
        """Define KRNet (flow model)."""
        a = self.args

        # enlarge the computation domain slightly
        xlb = -1.0 - 1e-2
        xhb =  1.0 + 1e-2

        self.pdf_model = BR_model.IM_rNVP_KR_CDF('pdf_model_rNVP_KR_CDF',
                                                a.n_dim,
                                                xlb, xhb,
                                                a.n_step,
                                                a.n_depth_krnet,       
                                                n_width=a.n_width_krnet,      
                                                shrink_rate=a.shrink_rate_krnet,
                                                flow_coupling=a.flow_coupling_krnet,
                                                n_bins=a.n_bins4cdf_krnet,
                                                rotation=a.rotation_krnet,
                                                bounded_supp=a.bounded_supp_krnet)

        # Build once with dummy input to allocate weights
        _ = self.pdf_model(tf.zeros((1, a.n_dim), dtype=tf.float32))

        # Initialize KRNet parameters for stability
        if a.rotation_krnet:
            self.pdf_model.WLU_data_initialization()
        self.pdf_model.actnorm_data_initialization()


    # ----------------------------------------------- classifier training -------------------------------------------------


    @tf.function
    def _train_classifier_step(self, x_batch, y_batch):
        """One training step for classifier neural network."""
        with tf.GradientTape() as tape:
            probs = self.classifier(x_batch)
            loss  = self.loss_fn(y_batch, probs)
        grads = tape.gradient(loss, self.classifier.trainable_weights)
        self.clf_optimizer.apply_gradients(zip(grads, self.classifier.trainable_weights))

        preds = tf.argmax(probs, axis=1, output_type=tf.int32)
        true  = tf.argmax(y_batch, axis=1, output_type=tf.int32)
        acc   = tf.reduce_mean(tf.cast(tf.equal(preds, true), tf.float32))
        return loss, acc
    
    #----------------------------train classifier for stage one----------------------------

    def solve_classifier_stage1(self, z_train, labels):
        """Train classifier on Stage-1 labeled data (from precomputed file)."""
        a = self.args
        self.ckpt.step.assign(0)
        ds = BR_data.dataflow(z_train.astype(np.float32),
                      buffersize=z_train.shape[0],
                      batchsize=a.batch_size,
                      y=labels.astype(np.float32)   
                     ).get_shuffled_batched_dataset()
        

        step_ckpts_dir = os.path.join(self.args.ckpts_dir, "adaptive_step_1")
        os.makedirs(step_ckpts_dir, exist_ok=True)
        step_manager = tf.train.CheckpointManager(self.ckpt, step_ckpts_dir, max_to_keep=5)
        
        cls_loss_vs_iter_per_adaptive_step = []
        cls_acc_vs_iter_per_adaptive_step = []
        cls_loss_vs_epoch_per_adaptive_step = []

        for epoch in range(1, a.n_epochs_nn + 1):
            epoch_losses = []
            for step, (xb, yb) in enumerate(ds):
                loss, acc = self._train_classifier_step(xb, yb)
                lv = float(loss.numpy())
                av = float(acc.numpy())
                cls_loss_vs_iter_per_adaptive_step.append(lv)
                cls_acc_vs_iter_per_adaptive_step.append(av)
                epoch_losses.append(lv)
                print(f"[Classifier: Initial step] epoch {epoch} step {step+1}  loss {loss.numpy():.6f}")

            cls_loss_vs_epoch_per_adaptive_step.append(np.mean(epoch_losses))

            self.ckpt.step.assign_add(1)

            if a.ckpt_step and (int(self.ckpt.step) % a.ckpt_step == 0):
                path = step_manager.save()
                print(f"[Classifier: Initial step]: Saved classifier checkpoint @ epoch {int(self.ckpt.step)}: {path}")
            
        final_path = step_manager.save()
        print(f"[Classifier: Initial step] final checkpoint -> {final_path}")

        np.savetxt(os.path.join(a.data_dir, f'cls_loss_vs_iter_adaptive_step1.dat'),
               np.array(cls_loss_vs_iter_per_adaptive_step, dtype=np.float32))
        np.savetxt(os.path.join(a.data_dir, f'cls_acc_vs_iter_adaptive_step1.dat'),
               np.array(cls_acc_vs_iter_per_adaptive_step, dtype=np.float32))
        np.savetxt(os.path.join(a.data_dir, f'cls_loss_vs_epoch_adaptive_step1.dat'),
               np.array(cls_loss_vs_epoch_per_adaptive_step, dtype=np.float32))
        
        self.cls_loss_vs_iter_all.extend(cls_loss_vs_iter_per_adaptive_step)
        self.cls_acc_vs_iter_all.extend(cls_acc_vs_iter_per_adaptive_step)
        self.cls_loss_vs_epoch_all.extend(cls_loss_vs_epoch_per_adaptive_step)


        np.savetxt(os.path.join(a.data_dir, 'cls_loss_vs_iter_all_steps.dat'), np.array(self.cls_loss_vs_iter_all,dtype=np.float32))
        np.savetxt(os.path.join(a.data_dir, 'cls_acc_vs_iter_all_steps.dat'),  np.array(self.cls_acc_vs_iter_all,dtype=np.float32))
        np.savetxt(os.path.join(a.data_dir, 'cls_loss_vs_epoch_all_steps.dat'), np.array(self.cls_loss_vs_epoch_all,dtype=np.float32))





    #----------------------------Retrain classifier for stage >= 2 on the updated dataset----------------------------

    def solve_classifier_stageN(self, z_train, labels, stage_idx):
        """
        Retrain classifier on updated (z_train, labels_int) for stage >= 2.
        """
        a = self.args

        self.ckpt.step.assign(0)

        step_ckpts_dir = os.path.join(self.args.ckpts_dir, f"adaptive_step_{stage_idx}")
        os.makedirs(step_ckpts_dir, exist_ok=True)
        step_manager = tf.train.CheckpointManager(self.ckpt, step_ckpts_dir, max_to_keep=5)



        ds = BR_data.dataflow(z_train.astype(np.float32),
                            buffersize=z_train.shape[0],
                            batchsize=a.batch_size,
                            y=labels.astype(np.float32)).get_shuffled_batched_dataset()
        
        cls_loss_vs_iter_per_adaptive_step = []
        cls_acc_vs_iter_per_adaptive_step = []
        cls_loss_vs_epoch_per_adaptive_step = []

        for epoch in range(1, a.n_epochs_nn + 1):
            epoch_losses = []
            for step, (xb, yb) in enumerate(ds):
                loss, acc = self._train_classifier_step(xb, yb)
                lvn = float(loss.numpy())
                avn = float(acc.numpy())
                cls_loss_vs_iter_per_adaptive_step.append(lvn)
                cls_acc_vs_iter_per_adaptive_step.append(avn)
                epoch_losses.append(lvn)
                print(f"[Classifier: Adaptive step {stage_idx -1}] epoch {epoch} step {step+1}  loss {loss.numpy():.6f}")

            cls_loss_vs_epoch_per_adaptive_step.append(np.mean(epoch_losses))

            self.ckpt.step.assign_add(1)
            if a.ckpt_step and (int(self.ckpt.step) % a.ckpt_step == 0):
                path = step_manager.save()
                print(f"[Classifier: Adaptive step {stage_idx-1}] Saved classifier checkpoint @ epoch {int(self.ckpt.step)}: {path}")
            
        # final checkpoint for this adaptive step 
        final_path = step_manager.save()
        print(f"[Classifier: Adaptive step {stage_idx -1}] final checkpoint -> {final_path}")

        np.savetxt(os.path.join(a.data_dir, f'cls_loss_vs_iter_adaptive_step{stage_idx}.dat'), np.array(cls_loss_vs_iter_per_adaptive_step,dtype=np.float32))
        np.savetxt(os.path.join(a.data_dir, f'cls_acc_vs_iter_adaptive_step{stage_idx}.dat'), np.array(cls_acc_vs_iter_per_adaptive_step,dtype=np.float32))
        np.savetxt(os.path.join(a.data_dir, f'cls_loss_vs_epoch_adaptive_step{stage_idx}.dat'), np.array(cls_loss_vs_epoch_per_adaptive_step,dtype=np.float32))
        
        self.cls_loss_vs_iter_all.extend(cls_loss_vs_iter_per_adaptive_step)
        self.cls_acc_vs_iter_all.extend(cls_acc_vs_iter_per_adaptive_step)
        self.cls_loss_vs_epoch_all.extend(cls_loss_vs_epoch_per_adaptive_step)

        

        np.savetxt(os.path.join(a.data_dir, 'cls_loss_vs_iter_all_steps.dat'), np.array(self.cls_loss_vs_iter_all,dtype=np.float32))
        np.savetxt(os.path.join(a.data_dir, 'cls_acc_vs_iter_all_steps.dat'),  np.array(self.cls_acc_vs_iter_all,dtype=np.float32))
        np.savetxt(os.path.join(a.data_dir, 'cls_loss_vs_epoch_all_steps.dat'), np.array(self.cls_loss_vs_epoch_all,dtype=np.float32))

        




    # -------------------------------------------------------------------------------------------------------


    @staticmethod
    def _entropy_from_probs(p):
        """Compute entropy from classifier probabilities (for KRNet training)."""
        eps = 1e-7
        p = np.clip(p, eps, 1.0 - eps)
        return -(p[:,0]*np.log(p[:,0]) + p[:,1]*np.log(p[:,1]))[:, None].astype(np.float32)
    


    def _build_flow_dataset_WNLL(self, n_points, stage_idx):
        """
        Build KRNet dataset for a given stage:
        """
        a = self.args
        z = np.random.uniform(-1.0, 1.0, size=(n_points, a.n_dim)).astype(np.float32)

        probs = self.classifier(tf.constant(z, dtype=tf.float32)).numpy()
        eps = 1e-7
        p = np.clip(probs, eps, 1.0 - eps)
        w = -(p[:,0]*np.log(p[:,0]) + p[:,1]*np.log(p[:,1]))
        w = w.astype(np.float32)[:, None]

        np.savez(os.path.join(a.data_dir, f"stage{stage_idx}_flow_training_WNLL.npz"), z=z, w=w)

        ds = tf.data.Dataset.from_tensor_slices((z, w))
        ds = ds.shuffle(buffer_size=z.shape[0], reshuffle_each_iteration=True).batch(a.krnet_batch_size)
        return ds



    #------------------------------------------------------------------------------------------------------------#

    @tf.function
    def _train_flow_step_WNLL(self, z_batch, w_batch):
        w = tf.stop_gradient(tf.cast(w_batch, tf.float32))
        with tf.GradientTape() as tape:
            log_q = self.pdf_model(z_batch)
            log_q = tf.clip_by_value(log_q, -23.0, 5.0)
            loss  = -tf.reduce_mean(w * log_q)
        grads = tape.gradient(loss, self.pdf_model.trainable_weights)
        self.flow_optimizer.apply_gradients(zip(grads, self.pdf_model.trainable_weights))
        return loss

    

    #------------------------------------------------------------------------------------------------------------#

    

    def solve_flow_stage(self, stage_idx):
        """
        Train KRNet with WNLL on a large uniform z batch using entropy weights.
        stage_idx : int
        """
        a = self.args
        ds = self._build_flow_dataset_WNLL(a.krnet_n_train,stage_idx)

        entropyloss_vs_iter_per_adaptive_step= []
        entropyloss_vs_epoch_per_adaptive_step= []

        for epoch in range(1, a.n_epochs_krnet + 1):
            epoch_losses = []
            for step, (z_b, w_b) in enumerate(ds):
                loss = self._train_flow_step_WNLL(z_b, w_b)
                els = float(loss.numpy())
                entropyloss_vs_iter_per_adaptive_step.append(els)
                epoch_losses.append(els)
                if stage_idx==1:
                    print(f"[KRNet: Initial step] epoch {epoch} step {step+1} loss {loss.numpy():.6f}")
                else:
                    print(f"[KRNet: Adaptive step {stage_idx -1}] epoch {epoch} step {step+1} loss {loss.numpy():.6f}")

            
            entropyloss_vs_epoch_per_adaptive_step.append(np.mean(epoch_losses))


        self.entropyloss_vs_iter_all.extend(entropyloss_vs_iter_per_adaptive_step)
        self.entropyloss_vs_epoch_all.extend(entropyloss_vs_epoch_per_adaptive_step)
        # save stage-specific loss file
        np.savetxt(os.path.join(a.data_dir, f'krnet_WNLL_loss_vs_iter_adaptive_step{stage_idx}.dat'), np.array(entropyloss_vs_iter_per_adaptive_step, dtype = np.float32))
        np.savetxt(os.path.join(a.data_dir, f'krnet_WNLL_loss_vs_epoch_adaptive_step{stage_idx}.dat'), np.array(entropyloss_vs_epoch_per_adaptive_step, dtype = np.float32))
        np.savetxt(os.path.join(a.data_dir, f'krnet_WNLL_loss_vs_iter_all.dat'), np.array(self.entropyloss_vs_iter_all, dtype = np.float32))
        np.savetxt(os.path.join(a.data_dir, f'krnet_WNLL_loss_vs_epoch_all.dat'), np.array(self.entropyloss_vs_epoch_all, dtype = np.float32))

        
        


    #------------------------------------------------------------------------------------------------------------#


    def inside_bounds_mask(self, phys):
        """Return boolean mask of which physical points are inside problem bounds."""
        keys = list(self.bounds.keys())
        lo0, hi0 = self.bounds[keys[0]]
        lo1, hi1 = self.bounds[keys[1]]

        m0 = (phys[:,0] >= lo0) & (phys[:,0] <= hi0)
        m1 = (phys[:,1] >= lo1) & (phys[:,1] <= hi1)

        return (m0 & m1)

    #------------------------------------------------------------------------------------------------------------#

    def sample_from_krnet(self, n_samples, save_tag, filter_inside=False):
        """
        Draw samples from KRNet, map to physical space, compute inside-bounds mask, 
        optionally filter to inside points, and save arrays.
        """
        a = self.args

        # 1) sample from KRNet's prior and map to z-space
        z0 = self.pdf_model.draw_samples_from_prior(n_samples, a.n_dim)
        z_raw = self.pdf_model.mapping_from_prior(z0).numpy().astype(np.float32)  # may be outside [-1,1]^2

        # 2) map to physical space
        phys_raw = to_physical(z_raw, self.bounds).astype(np.float32)

        # 3) compute inside-bounds mask (based on physical ranges)
        mask_in = self.inside_bounds_mask(phys_raw)

        # 4) choose what to return/save
        if filter_inside:
            z_out    = z_raw[mask_in]
            phys_out = phys_raw[mask_in]
        else:
            z_out    = z_raw
            phys_out = phys_raw

        # 5) save arrays
        np.save(os.path.join(a.data_dir, f"krnet_samples_z_raw_{save_tag}.npy"),    z_raw)
        np.save(os.path.join(a.data_dir, f"krnet_samples_phys_raw_{save_tag}.npy"), phys_raw)
        np.save(os.path.join(a.data_dir, f"krnet_samples_mask_in_{save_tag}.npy"),  mask_in)
        if filter_inside:
            np.save(os.path.join(a.data_dir, f"krnet_samples_z_in_{save_tag}.npy"),    z_out)
            np.save(os.path.join(a.data_dir, f"krnet_samples_phys_in_{save_tag}.npy"), phys_out)


        header_keys = list(self.bounds.keys())
        header_raw  = ", ".join(header_keys)

        # Save RAW physical samples to .txt (all KRNet proposals, regardless of inside/outside)
        out_txt_raw = os.path.join(a.data_dir, f"krnet_samples_phys_raw_{save_tag}.txt")
        np.savetxt(out_txt_raw, phys_raw, fmt="%.6e", header=header_raw)
        print(f"[save txt] Saved RAW KRNet physical samples -> {out_txt_raw}")

        # Save the RETURNED set (inside-only if filter_inside=True, else raw)
        out_txt_ret = os.path.join(a.data_dir, f"krnet_samples_phys_{save_tag}.txt")
        np.savetxt(out_txt_ret, phys_out, fmt="%.6e", header=header_raw)
        print(f"[save txt] Saved RETURNED KRNet physical samples -> {out_txt_ret}")

        n_in = int(mask_in.sum())
        print(f"[KRNet] drew {n_samples} samples -> inside: {n_in}, outside: {n_samples - n_in}. "
            f"{'Returned inside only.' if filter_inside else 'Returned raw (with mask).'}")

        return z_out, phys_out, mask_in


    # ------------------------------------------ Matlab call ------------------------------------------


    
    def _run_matlab_and_collect_labels(self, phys_points, stage):
        """
        Parallel MATLAB labeling via subprocess for any problem.
        Expects MATLAB functions with signature: func(input_file, output_file)
        P1: run_channel_flow_parallel
        P2: run_rbc_parallel
        P3: run_dhc_parallel
        """

        a  = self.args
        pb = a.probsetup

        # -------- paths --------
        os.makedirs(a.stage_data_dir, exist_ok=True)
        input_txt = os.path.join(a.stage_data_dir, f"problem{pb}_input_stage{stage}.txt")
        out_txt   = os.path.join(a.stage_data_dir, f"problem{pb}_stage{stage}.txt")

        # -------- prepare and save inputs for MATLAB --------
        #  P1: [Re, log10(delta)]  -> MATLAB expects [Re, delta]
        #  P2: [Ra, log10(delta)]  -> MATLAB expects [Ra, delta]
        #  P3: [Ra, Pr]            -> MATLAB expects [Ra, Pr]
        
        if pb in (1, 2):
            phys_to_mat = phys_points.copy().astype(np.float64)
            phys_to_mat[:, 1] = np.power(10.0, phys_to_mat[:, 1])  # log10(delta) -> delta
            np.savetxt(input_txt, phys_to_mat, delimiter=",")
        else:
            np.savetxt(input_txt, phys_points.astype(np.float64), delimiter=",")

        print(f"[Stage {stage}] Saved MATLAB input -> {input_txt}")

        # -------- choose MATLAB function --------
        if pb == 1:
            matlab_func = "run_channel_flow_parallel"
        elif pb == 2:
            matlab_func = "run_rbc_parallel"
        elif pb == 3:
            matlab_func = "run_dhc_parallel"
        else:
            raise ValueError(f"Unknown probsetup={pb}")


         # -------- run MATLAB --------
        matlab_bin  = os.environ.get("MATLAB_BIN") or getattr(a, "matlab_bin", "/Applications/MATLAB_R2025a.app/bin/matlab")
        toolbox_dir = os.environ.get("IFISS_DIR")  or getattr(a, "matlab_toolbox_dir", "/Users/user/Desktop/ifiss3.7")
        input_abs    = os.path.abspath(input_txt)
        out_abs      = os.path.abspath(out_txt)
        
        
        # MATLAB likes single quotes; escape any just in case
        def mquote(p: str) -> str:
            return p.replace("'", "''")

        tb_q  = mquote(toolbox_dir)
        in_q  = mquote(input_abs)
        out_q = mquote(out_abs)

        matlab_cmd = [
            matlab_bin, 
            "-sd", toolbox_dir,
            "-batch",
            (
                f"addpath(genpath('{tb_q}'));"
                f"{matlab_func}('{in_q}','{out_q}')"
            )
        ]


        print(f"[Stage {stage}] Launch MATLAB: {matlab_cmd}")
        subprocess.run(matlab_cmd, check=True)
        print(f"[Stage {stage}] MATLAB done. Results -> {out_txt}")

        # -------- parse MATLAB results --------
        mat = np.genfromtxt(out_txt, delimiter=',', comments='%', dtype=float)
        if mat.ndim == 1:
            mat = mat[None, :]

        if pb == 1:
            # file columns expected: Re, delta, label, ...
            Re_m = mat[:, 0].astype(np.float32)
            del_m  = mat[:, 1].astype(np.float32)
            lab_m  = mat[:, 2].astype(np.int32)
            logdelta_m = np.log10(del_m + 1e-300).astype(np.float32)
            params_m   = np.stack([Re_m, logdelta_m], axis=1)
            labels     = lab_m

        elif pb == 2:
            # file columns expected: Ra, delta, label, KE, ...
            Ra_m    = mat[:, 0].astype(np.float32)
            delta_m = mat[:, 1].astype(np.float32)
            lab_m   = mat[:, 2].astype(np.int32)
            KE      = mat[:, 3]
            logdelta_m = np.log10(delta_m + 1e-300).astype(np.float32)
            KE_THRESH  = 5e-4
            labels     = np.where(KE > KE_THRESH, 1, lab_m).astype(int)
            params_m   = np.stack([Ra_m, logdelta_m], axis=1)

        elif pb == 3:
            # file columns expected: Ra, Pr, label, ...
            Ra_m  = mat[:, 0].astype(np.float32)
            Pr_m  = mat[:, 1].astype(np.float32)
            lab_m = mat[:, 2].astype(np.int32)
            params_m = np.stack([Ra_m, Pr_m], axis=1)
            labels   = lab_m

        # -------- map to z-space --------
        z_m = to_z(params_m, self.bounds).astype(np.float32)
        return z_m, labels, out_txt




    
    # #------------------------------------------ Main training function ------------------------------------------


    def train(self):
        """
        Stage 1: load labeled file -> train classifier.
        Stage 2+: KRNet WNLL -> sample -> MATLAB labels -> update set -> retrain classifier.
        """
        a = self.args

        tf.random.set_seed(212421)
        np.random.seed(212421)

        cur_z = None
        cur_lab = None

        for i in range(1, a.max_stages + 1):

            if i == 1:
                # ---------------- Stage 1 ----------------
                # Load first-stage labeled file
                z_train, labels_int, params_phys = load_stage1_data(
                    a.probsetup, self.bounds, data_dir=a.stage_data_dir
                )

                # One-hot encode labels (using member_encode)
                y_onehot = np.array([member_encode(int(y)) for y in labels_int], dtype=np.float32)

                # Train classifier 
                self.solve_classifier_stage1(z_train, y_onehot)

                # Keep dataset in memory for later stages
                cur_z   = z_train.astype(np.float32)
                cur_lab = labels_int.astype(np.int32)

                if a.max_stages == 1:
                    print("Adaptive Step 1 done (single-step run).")
                    return

            else:
                # ---------------- Stage 2,3,... ----------------
                # 1) Train KRNet with WNLL
                self.solve_flow_stage(stage_idx=i-1)

                # 2) Draw candidate points from KRNet
                z_new, phys_new, _mask_in = self.sample_from_krnet(
                    n_samples=a.n_adaptive_samples,
                    save_tag=f"stage{i-1}",
                    filter_inside=True
                )

                # 3) Run MATLAB simulations
                _, labels_new_int, _ = self._run_matlab_and_collect_labels(phys_new, i)


                # 4) Update dataset (merge or replace)
                upd = getattr(a, "update_strategy", "merge")
                if upd == "replace":
                    cur_z   = z_new.astype(np.float32)
                    cur_lab = labels_new_int
                    print(f"[Adaptive Step {i}] update_strategy=replace -> classifier dataset = {cur_z.shape[0]} samples.")
                else:
                    # default: merge
                    cur_z   = np.concatenate([cur_z, z_new.astype(np.float32)], axis=0)
                    cur_lab = np.concatenate([cur_lab, labels_new_int], axis=0)
                    print(f"[Adaptive Step {i}] update_strategy=merge -> classifier dataset = {cur_z.shape[0]} samples.")


                # Convert updated labels to one-hot
                y_cur_onehot = np.array([member_encode(int(y)) for y in cur_lab], dtype=np.float32)

                # 5) Retrain classifier
                self.solve_classifier_stageN(cur_z, y_cur_onehot, stage_idx=i)

        print("All adaptive steps finished.")

