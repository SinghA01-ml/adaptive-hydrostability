function run_channel_flow_parallel(input_file, output_file)
% input_file : Two columns [Re, delta]
% output_file: Re, delta, label, it, ib, flag

    setpath;
    
    % ---- Globals ----
    global BATCH DELTA FID RE
    BATCH = 1;

    tstart = tic;
    fprintf('Generating channel flow problem data set ... \n')

    % ---- Read inputs ----
    X = readmatrix(input_file);
    if size(X,2) < 2
        error('Input must have 2 columns: [Re, delta].');
    end

    reynold  = X(:,1)';
    deltaset = X(:,2)';
    nre = numel(reynold);

    %----- setup problem data files
    system('/bin/cp ./stokes_flow/test_problems/symstep_flowX.m ./stokes_flow/specific_flow.m');
    system('/bin/cp ./stokes_flow/test_problems/symstep_bc.m ./stokes_flow/stream_bc.m');


    % ---- preprocessing to set up grid and matrices ----
    testproblem = 'T-NS_batch';

    [KID,msg] = fopen(testproblem,'w');
    if KID < 0
        error('Cannot create %s: %s', testproblem, msg);
    end
    fprintf(KID,'16%%\n5%%\n1%%\n4%%\n');
    fprintf(KID,'%48s\n','%---------- grid data file for flow test problem');
    fclose(KID);

    % ---- set up matrices ----
    [FID,msg] = fopen(testproblem,'r');
    if ~strcmp(msg,'')
        error('INPUT FILE ERROR: %s', msg);
    else
        disp(['Working in batch mode from data file ', testproblem])
    end

    symstep_stokes

    % ---- Parallel execution ----
    poolSize = min(nre, feature('numcores'));
    if isempty(gcp('nocreate')), parpool(poolSize); end

    parfor test = 1:nre
        tt = test;
        fprintf('\n [%g]', tt)

        re = reynold(tt); RE = re;
        fprintf('\n Reynold number %g', re)

        pr = deltaset(tt); DELTA = pr;
        fprintf('\n perturbation is %g\n', pr)

        testproblem = ['T-NS_test', num2str(tt)];
        batchfile   = [testproblem, '_batch.m'];

        % ---- write batch file ----
        [FID,msg] = fopen(batchfile,'w');
        if FID < 0
            error('Cannot create %s: %s', batchfile, msg);
        end
        fprintf(FID,'%g%%\n%g%%\n', re, pr);
        fprintf(FID,'1e15%%\n6%%\n3e-6%%\n2%%\n2500%%\n0%%\n');
        fprintf(FID,'%43s\n','%---------- data file for flow test problem');
        fclose(FID);

        % ---- execute batch file ----
        batchprocess(testproblem)
    end

    delete(gcp)
    etoc = toc(tstart);
    fprintf('Bingo!\n')
    fprintf('\n  %9.4e seconds\n\n\n', etoc)

    % ---- Collect results -> output_file ----
    gohome, cd datafiles
    load step_stokes_nobc.mat

    [RID,msg] = fopen(output_file,'w');
    if RID < 0
        error('Cannot open output file: %s', msg);
    end
    fprintf(RID,'%43s\n','%------------ channel flow grid5 label data');

    for test = 1:nre
        testresults = ['symmetric_flow_output', num2str(test), '.mat'];
        load(testresults)

        % ---- plotting ----
        figure(100+test), subplot(121)
        plot(10:1200, vty(10:1200), '.-r'), axis square
        xlabel('step'), title('mean vorticity')
        subplot(122)
        plot(1000:1200, vty(1000:1200), '.-r'), axis square
        xlabel('step'), title('zoom')

        % ---- bifurcation check ----
        vv = [-By, Bx] * U;
        nvv = length(vv);
        w = G(1:nvv,1:nvv) \ vv;

        [label, it, ib] = symstep_bdryvorticity( ...
            domain, qmethod, xy, bound, w, 10+test, 'or-');

        % ---- incomplete integration check ----
        if 1200 == length(time)
            flag = 0;
        else
            flag = 1;
        end

        %---------- write the result to the file
        fprintf(RID,'%g,%g,%g,%g,%g,%g\n', ...
            reynold(test), deltaset(test), label, it, ib, flag);
    end

    fclose(RID);
end
