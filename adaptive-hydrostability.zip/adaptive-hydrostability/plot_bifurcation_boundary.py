import os
import argparse
import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf

from bifurcation_das import get_problem_bounds, to_z
from shallowNN_tf import ClassificationNN



def restore_classifier_for_step(ckpts_dir, step, nn_depth, n_hidden_nn, activation_nn, seed=212421):
    """
    Restore the classifier for a specific adaptive step from:
        {ckpts_dir}/adaptive_step_{step}
    """
    tf.random.set_seed(seed)
    np.random.seed(seed)

    model = ClassificationNN(
        input_dim=2,
        num_hidden_layers=nn_depth,
        hidden_neurons=n_hidden_nn,
        activation_hidden=activation_nn
    )
    _ = model(tf.zeros((1, 2), dtype=tf.float32))

    # Create a checkpoint object with the same structure as training
    optimizer = tf.keras.optimizers.legacy.SGD(learning_rate=0.15)
    ckpt = tf.train.Checkpoint(step=tf.Variable(0), optimizer=optimizer, net=model)

    # Step-specific checkpoint folder
    step_dir = os.path.join(ckpts_dir, f"adaptive_step_{step}")
    if not os.path.isdir(step_dir):
        raise FileNotFoundError(
            f"Step-specific checkpoint folder not found: {step_dir}\n"
            f"Make sure you saved per-step checkpoints during training."
        )

    step_manager = tf.train.CheckpointManager(ckpt, step_dir, max_to_keep=5)
    latest = step_manager.latest_checkpoint
    if latest is None:
        tag_file = os.path.join(step_dir, "ckpt_path.txt")
        if os.path.exists(tag_file):
            with open(tag_file, "r") as f:
                latest = f.read().strip()

    if latest is None:
        raise FileNotFoundError(
            f"No checkpoint found in {step_dir}. "
            f"Expected a final save for adaptive step {step}."
        )

    ckpt.restore(latest).expect_partial()
    print(f"[Restore] Loaded checkpoint for adaptive step {step}: {latest}")
    return model


def default_phys_ranges(probsetup):
    """Physical sampling ranges for the right panel."""
    if probsetup == 1:
        return dict(xmin=160.0, xmax=240.0, ymin=-5.5, ymax=-2.0)
    elif probsetup == 2:
        return dict(xmin=1500, xmax=40, ymin=-16, ymax=-2)
    elif probsetup == 3:
        return dict(xmin=2.92e9, xmax=2.9e7, ymin=0,  ymax=1000)
    else:
        raise ValueError(f"Unknown probsetup {probsetup}")


def _load_single_stage_phys(probsetup, stage, stage_data_dir):
    """Load one stage's physical parameters + labels from text files."""
    if stage == 1:
        fname = os.path.join(stage_data_dir, f"problem{probsetup}.txt")
    else:
        fname = os.path.join(stage_data_dir, f"problem{probsetup}_stage{stage}.txt")

    if not os.path.exists(fname):
        raise FileNotFoundError(f"Stage file not found: {fname}")

    mat = np.genfromtxt(fname, delimiter=',', comments='%', dtype=float)
    if mat.ndim == 1:
        mat = mat[None, :]

    if probsetup == 1:
        Re     = mat[:, 0].astype(np.float32)
        delta  = mat[:, 1].astype(np.float32)
        label  = mat[:, 2].astype(np.int32)
        logdelta = np.log10(delta + 1e-300).astype(np.float32)
        params_phys = np.stack([Re, logdelta], axis=1)
        
    elif probsetup == 2:
        Ra    = mat[:, 0].astype(np.float32)
        asymT = mat[:, 1].astype(np.float32)
        label = mat[:, 2].astype(np.int32)
        logasymT = np.log10(asymT + 1e-300).astype(np.float32)
        params_phys = np.stack([Ra, logasymT], axis=1)
        
    elif probsetup == 3:
        Ra    = mat[:, 0].astype(np.float32)
        Pr    = mat[:, 1].astype(np.float32)
        label = mat[:, 2].astype(np.int32)
        params_phys = np.stack([Ra, Pr], axis=1)
    else:
        raise ValueError(f"Unknown probsetup {probsetup}")

    return params_phys, label


def load_training_set_cumulative(probsetup, upto_stage, stage_data_dir, cumulative=True):
    """
    Return the training set actually used up to 'upto_stage'.
    If cumulative=True, concatenates stage1 + stage2 + ... + stageN.
    If cumulative=False, returns only that stage's file.
    """
    if not cumulative:
        return _load_single_stage_phys(probsetup, upto_stage, stage_data_dir)

    all_params = []
    all_labels = []

    params1, labels1 = _load_single_stage_phys(probsetup, 1, stage_data_dir)
    all_params.append(params1); all_labels.append(labels1)

    for s in range(2, upto_stage + 1):
        fname = os.path.join(stage_data_dir, f"problem{probsetup}_stage{s}.txt")
        if not os.path.exists(fname):
            print(f"[warn] Missing file for adaptive step {s}: {fname} (skipping)")
            continue
        ps, ls = _load_single_stage_phys(probsetup, s, stage_data_dir)
        all_params.append(ps); all_labels.append(ls)

    params_all = np.concatenate(all_params, axis=0) if all_params else np.zeros((0, 2), np.float32)
    labels_all = np.concatenate(all_labels, axis=0) if all_labels else np.zeros((0,), np.int32)
    return params_all, labels_all


# ---------------- Main plotting ---------------- #

def plot_two_panel_by_step(probsetup,
                           adaptive_step,
                           stage_data_dir,
                           data_dir,
                           ckpts_dir,
                           nn_depth,
                           n_hidden_nn,
                           activation_nn,
                           npts_large=200000,
                           re_min=None, re_max=None, y_min=None, y_max=None,
                           out_name=None,
                           cumulative_left=True,
                           seed=212421):
    """
    Two-panel figure for a given ADAPTIVE STEP:
      Left : training set used up to this step (cumulative by default), colored by P(class=1)
      Right: large physical random sample colored by P(class=1)
    """
    np.random.seed(seed)
    tf.random.set_seed(seed)

    fig_dir = os.path.join(data_dir, "saved_figures")
    os.makedirs(fig_dir, exist_ok=True)

    bounds = get_problem_bounds(probsetup)

    # --- restore the classifier for this adaptive step ---
    model = restore_classifier_for_step(
        ckpts_dir=ckpts_dir,
        step=adaptive_step,
        nn_depth=nn_depth,
        n_hidden_nn=n_hidden_nn,
        activation_nn=activation_nn,
        seed=seed
    )

    params_phys_left, _ = load_training_set_cumulative(
        probsetup, adaptive_step, stage_data_dir, cumulative=cumulative_left
    )
    if params_phys_left.size:
        z_left = to_z(params_phys_left.astype(np.float32), bounds)
        p_left = model(tf.constant(z_left, dtype=tf.float32)).numpy()[:, 0]
    else:
        p_left = np.array([])

    rng = default_phys_ranges(probsetup)
    if re_min is not None: rng["xmin"] = re_min
    if re_max is not None: rng["xmax"] = re_max
    if y_min  is not None: rng["ymin"] = y_min
    if y_max  is not None: rng["ymax"] = y_max
    
    
    if probsetup == 1:
        phys_large_x = np.random.uniform(
            rng["xmin"], rng["xmax"], npts_large
        ).astype(np.float32) # uniform sampling for first parameter  (used for first problem)
    else:
        phys_large_x = np.random.normal(
            rng["xmin"], rng["xmax"], npts_large
        ).astype(np.float32) # normal sampling for first parameter (used for second and third problems)

    
    phys_large_y = np.random.uniform(rng["ymin"], rng["ymax"], npts_large).astype(np.float32) # uniform sampling for second parameter (used for all three problems)

    phys_large   = np.stack([phys_large_x, phys_large_y], axis=1)
    z_large      = to_z(phys_large, bounds)
    p_large      = model(tf.constant(z_large, dtype=tf.float32)).numpy()[:, 0]

    if probsetup == 1:
        xlab = "Reynolds number"
        ylab = "logarithm of inlet perturbation"

    elif probsetup == 2:
        xlab = "Rayleigh number"
        ylab = "logarithm of hot wall perturbation"

    elif probsetup == 3:
        xlab = "Rayleigh number"
        ylab = "Prandtl number"

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(8.9, 3.8))

    if adaptive_step == 1:
        title_left  = "Initial training data classifications"
        title_right = "Predicted bifurcation boundary"
    else:
        title_left  = f"Adaptive step {adaptive_step - 1}: training data classifications"
        title_right = f"Predicted bifurcation boundary"


    

    # LEFT: training set colored by P(class=1)
    if params_phys_left.size:
        ax1.scatter(params_phys_left[:, 0], params_phys_left[:, 1],
                    8, c=p_left, cmap='cool_r', edgecolor='none')
    ax1.set_xlabel(xlab)
    ax1.set_ylabel(ylab)
    ax1.set_title(title_left)

    # RIGHT: large physical random sample colored by P(class=1)
    
    if probsetup == 1:
        ax2.scatter(
            phys_large[:, 0],
            phys_large[:, 1],
            2,
            c=p_large,
            cmap='twilight',
            edgecolor='none'
        )
    else:
        ax2.scatter(
            phys_large[:, 0],
            phys_large[:, 1],
            2,
            c=p_large,
            cmap='cool_r',
            edgecolor='none'
        )

               
    ax2.set_xlabel(xlab)
    ax2.set_title(title_right)

    plt.tight_layout()
    if out_name is None:
        out_name = f"bifurcation_probabilities_adaptive_step{adaptive_step}.png"
    out_path = os.path.join(fig_dir, out_name)
    plt.savefig(out_path, dpi=300)
    plt.close(fig)
    print(f"[Saved] {out_path}")


# ---------------- CLI ---------------- #

def parse_args():
    p = argparse.ArgumentParser(description="Two-panel boundary plot per adaptive step.")
    p.add_argument('--probsetup', type=int, default=1,
                   help='1=channel flow, 2=Rayleigh--Benard, 3=differentially heated cavity')
    p.add_argument('--adaptive_step', type=int, default=1,
                   help='Adaptive step to visualize (1, 2, 3, 4, ...)')
    p.add_argument('--stage_data_dir', type=str, default='./data',
                   help='Folder containing problem{1,2,3}.txt and problem{p}_stage{s}.txt')
    p.add_argument('--data_dir', type=str, default='./flow_data_storage',
                   help='Folder to save figures')
    p.add_argument('--ckpts_dir', type=str, default='./nn_ckpts',
                   help='Root folder that contains per-step subfolders: adaptive_step_{k}')

    # Classifier neural network hyperparams (must match training)
    p.add_argument('--nn_depth', type=int, default=1)
    p.add_argument('--n_hidden_nn', type=int, default=32)
    p.add_argument('--activation_nn', type=str, default='sigmoid')

    # Large sampling controls
    p.add_argument('--npts_large', type=int, default=200000,
                   help='Number of large physical random samples for the right panel')
    p.add_argument('--re_min', type=float, default=None, help='Override xmin')
    p.add_argument('--re_max', type=float, default=None, help='Override xmax')
    p.add_argument('--y_min',  type=float, default=None, help='Override ymin')
    p.add_argument('--y_max',  type=float, default=None, help='Override ymax')

   
    # Output
    p.add_argument('--out_name', type=str, default=None,
                   help='Optional filename (defaults to bifurcation_probabilities_adaptive_step{step}.png)')

    p.add_argument('--no_cumulative', action='store_true',
                   help='If set, left panel shows only this step’s file (not cumulative).')
    return p.parse_args()


if __name__ == "__main__":
    args = parse_args()
    plot_two_panel_by_step(
        probsetup=args.probsetup,
        adaptive_step=args.adaptive_step,
        stage_data_dir=args.stage_data_dir,
        data_dir=args.data_dir,
        ckpts_dir=args.ckpts_dir,
        nn_depth=args.nn_depth,
        n_hidden_nn=args.n_hidden_nn,
        activation_nn=args.activation_nn,
        npts_large=args.npts_large,
        re_min=args.re_min, re_max=args.re_max,
        y_min=args.y_min, y_max=args.y_max,
        out_name=args.out_name,
        cumulative_left=not args.no_cumulative
    )
