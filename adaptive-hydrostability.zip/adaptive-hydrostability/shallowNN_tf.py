import tensorflow as tf
from tensorflow.keras import layers, Model
import numpy as np 

tf.random.set_seed(212421)
np.random.seed(212421)

# --- Classifier neural network ---

class ClassificationNN(Model):
    
    def __init__(self, name="ClassificationNN", input_dim=2, num_hidden_layers=1,
                 hidden_neurons=32, activation_hidden='sigmoid', **kwargs):
        super(ClassificationNN, self).__init__(name=name, **kwargs)

        self.input_dim = input_dim
        self.num_hidden_layers = num_hidden_layers
        self.hidden_neurons = hidden_neurons
        self.activation_hidden = activation_hidden
        self.hidden_layers = []

        common_seed = 212421 

        for i in range(num_hidden_layers):
            if i == 0:  
                fan_in = input_dim
            else:  
                fan_in = hidden_neurons
            fan_out = hidden_neurons  

            std_dev_normal = np.sqrt(2.0 / (fan_in + fan_out) )

            self.hidden_layers.append(
                layers.Dense(
                    units=hidden_neurons,
                    activation=activation_hidden,  
                    kernel_initializer=tf.keras.initializers.RandomNormal(
                        mean=0.0, stddev=std_dev_normal, seed=common_seed + i), 
                    bias_initializer=tf.keras.initializers.RandomNormal(
                        mean=0.0, stddev=std_dev_normal, seed=common_seed + i + 100), 
                    name=f'hidden_layer_{i+1}'
                )
            )


        self.output_layer = layers.Dense(
            units=2, 
            activation='softmax', 
            kernel_initializer=tf.keras.initializers.RandomUniform(
                minval=-1.0, maxval=1.0, seed=common_seed + num_hidden_layers), 
            bias_initializer=tf.keras.initializers.RandomUniform(
                minval=-1.0, maxval=1.0, seed=common_seed + num_hidden_layers + 100), 
            name='output_layer'
        )

    def call(self, inputs):
        
        inputs = tf.cast(inputs, tf.float32)

        x = inputs
        for layer in self.hidden_layers:
            x = layer(x)

        return self.output_layer(x)

    def model_summary(self, input_dim):
        """
        Prints a summary of the model architecture.
        """
        self.build(input_shape=(None, input_dim)) 
        self.summary()


